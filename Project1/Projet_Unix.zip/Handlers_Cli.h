void hand_reveil(int sig){
    printf("Signal %d recu\n", sig);
}